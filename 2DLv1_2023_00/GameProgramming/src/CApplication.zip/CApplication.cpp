#include "CRectangle.h"

void CApplicationStart()
{
	CInput input;
}